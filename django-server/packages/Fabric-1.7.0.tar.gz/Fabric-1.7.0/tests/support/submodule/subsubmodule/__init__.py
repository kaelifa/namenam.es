from fabric.api import task

@task
def deeptask():
    pass
