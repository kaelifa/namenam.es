tinyMCE.addI18n("pl.grappelli_contextmenu",{
grappelli_contextmenu_insertpbefore_desc:"Wstaw paragraf PRZED aktualnym elementem",
grappelli_contextmenu_insertpafter_desc:"Wstaw paragraf PO aktualnym elemencie",
grappelli_contextmenu_insertpbeforeroot_desc:"Wstaw paragraf PRZED aktualnym BAZOWYM elementem",
grappelli_contextmenu_insertpafterroot_desc:"Wstaw paragraf PO aktualnym BAZOWYM elemencie",
grappelli_contextmenu_delete_desc:"Usuń aktualny element",
grappelli_contextmenu_deleteroot_desc:"Usuń aktualny BAZOWY element",
grappelli_contextmenu_moveup_desc:"PRZENIEŚ aktualny ELEMENT WYŻEJ",
grappelli_contextmenu_moveuproot_desc:"PRZENIEŚ aktualny BAZOWY element WYŻEJ",

P_grappelli_contextmenu_insertpbefore_desc:"Wstaw paragraf PRZED aktualnym elementem",
P_grappelli_contextmenu_insertpafter_desc:"Wstaw paragraf PO aktualnym elemencie",
P_grappelli_contextmenu_insertpbeforeroot_desc:"Wstaw paragraf PRZED aktualnym BAZOWYM elementem",
P_grappelli_contextmenu_insertpafterroot_desc:"Wstaw paragraf PO aktualnym BAZOWYM elemencie",
P_grappelli_contextmenu_delete_desc:"Usuń aktualny element",
P_grappelli_contextmenu_deleteroot_desc:"Usuń aktualny BAZOWY element",
P_grappelli_contextmenu_moveup_desc:"PRZENIEŚ aktualny ELEMENT WYŻEJ",
P_grappelli_contextmenu_moveuproot_desc:"PRZENIEŚ aktualny BAZOWY element WYŻEJ"
});
