// dropped
// not used in grappelli
// not used in django either
// kept this file to prevent 404