from grappelli.dashboard.dashboards import *
from grappelli.dashboard.registry import *
