"""
South - Useable migrations for Django apps
"""

__version__ = "0.8.2"
__authors__ = [
    "Andrew Godwin <andrew@aeracode.org>",
    "Andy McCurdy <andy@andymccurdy.com>"
]
