request = {
    "method": "GET",
    "uri": uri("/favicon.ico"),
    "version": (1, 1),
    "headers": [
        ("HOST", "0.0.0.0=5000"),
        ("USER-AGENT", "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9) Gecko/2008061015 Firefox/3.0"),
        ("ACCEPT", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"),
        ("ACCEPT-LANGUAGE", "en-us,en;q=0.5"),
        ("ACCEPT-ENCODING", "gzip,deflate"),
        ("ACCEPT-CHARSET", "ISO-8859-1,utf-8;q=0.7,*;q=0.7"),
        ("KEEP-ALIVE", "300"),
        ("CONNECTION", "keep-alive")
    ],
    "body": b""
}
